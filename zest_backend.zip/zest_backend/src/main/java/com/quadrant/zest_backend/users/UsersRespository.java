package com.quadrant.zest_backend.users;

import com.quadrant.zest_backend.products.Products;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Repository
public interface UsersRespository extends JpaRepository<Users,Long> {
    @Modifying
    @Query(value = "insert into users(username,password) values(?1,?2)",nativeQuery = true)
    @Transactional
    public void saveUser(String username, String password);

    @Query(value = "select * from users",nativeQuery = true)
    public List<Users> listAllUsers();

    @Modifying
    @Query(value = "update users set username=?1, password=?2 where id=?3",nativeQuery = true)
    @Transactional
    public void updateUser(String username,String password, long id);

    @Modifying
    @Query(value = "delete from users where id=?1",nativeQuery = true)
    @Transactional
    public void deleteUserById(long id);

    @Query(value = "select * from users where username=?1", nativeQuery = true)
    public Optional<Users> findUserByName(String username);

    @Query(value = "select * from users where id =?1", nativeQuery = true)
    public String findUserById(long id);
}
