package com.quadrant.zest_backend.products;

import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ProductsService {
    private final ProductsRepository productsRepository;

    public ProductsService(ProductsRepository productsRepository) {
        this.productsRepository = productsRepository;
    }

    public void saveProduct(String name, double price){
        productsRepository.saveProduct(name,price);
    }

    public List<Products> listAllProducts(){
        return productsRepository.listAllProducts();
    }

    public void updateProductPrice(double price, long id){
        productsRepository.updateProductPrice(price,id);
    }

    public void deleteProductById(long id){
        productsRepository.deleteProductById(id);
    }

    public Optional<Products> findProductByName(String name){
        Optional<Products> productToFind = productsRepository.findProductByName(name);
        return productToFind;
    }

    public Optional<Products> findProductById(long id){
        Optional<Products> productToFind = productsRepository.findProductById(id);
        return productToFind;
    }
}
