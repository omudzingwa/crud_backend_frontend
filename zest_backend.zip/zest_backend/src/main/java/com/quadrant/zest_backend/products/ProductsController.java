package com.quadrant.zest_backend.products;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin("http://localhost:3000")
@RequestMapping("/products")
public class ProductsController {
    private final ProductsService productsService;

    public ProductsController(ProductsService productsService) {
        this.productsService = productsService;
    }

    @PostMapping("/save")
    public ResponseEntity<?> saveProduct(@RequestBody Products products){
        productsService.saveProduct(products.getName(),products.getPrice());
        return new ResponseEntity<>("Product saved successfully", HttpStatus.OK);
    }

    @GetMapping("/listall")
    public ResponseEntity<?> listAllProducts(){
        return new ResponseEntity<>(productsService.listAllProducts(),HttpStatus.OK);
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<?> updateProductPrice(@RequestBody Products products, @PathVariable("id") long id){
        productsService.updateProductPrice(products.getPrice(),id);
        return new ResponseEntity<>("Product updated", HttpStatus.OK);
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<?> deleteProduct(@PathVariable("id") long id){
        productsService.deleteProductById(id);
        return new ResponseEntity<>("Product deleted", HttpStatus.OK);
    }

}
