package com.quadrant.zest_backend.users;

import com.quadrant.zest_backend.products.Products;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UsersService {
    private final UsersRespository usersRespository;

    public UsersService(UsersRespository usersRespository) {
        this.usersRespository = usersRespository;
    }

    public void saveProduct(String username, String password){
        usersRespository.saveUser(username,password);
    }

    public List<Users> listAllUsers(){
        return usersRespository.listAllUsers();
    }

    public void updateUser(String username, String password, long id){
        usersRespository.updateUser(username,password,id);
    }

    public void deleteUserById(long id){
        usersRespository.deleteUserById(id);
    }

    public Optional<Users> findUserByName(String username){
        Optional<Users> userToFind = usersRespository.findUserByName(username);
        return userToFind;
    }

    public String findUserById(long id){
        String userToFind = usersRespository.findUserById(id);
        return userToFind;
    }

}
