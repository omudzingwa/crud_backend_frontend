package com.quadrant.zest_backend.products;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Repository
public interface ProductsRepository extends JpaRepository<Products,Long> {
    @Modifying
    @Query(value = "insert into products(name,price) values(?1,?2)",nativeQuery = true)
    @Transactional
    public void saveProduct(String name, double price);

    @Query(value = "select * from products",nativeQuery = true)
    public List<Products> listAllProducts();

    @Modifying
    @Query(value = "update products set price=?1 where id=?2",nativeQuery = true)
    @Transactional
    public void updateProductPrice(double price, long id);

    @Modifying
    @Query(value = "delete from products where id=?1",nativeQuery = true)
    @Transactional
    public void deleteProductById(long id);

    @Query(value = "select * from products where name=?1", nativeQuery = true)
    public Optional<Products> findProductByName(String name);

    @Query(value = "select * from products where id =?1", nativeQuery = true)
    public Optional<Products> findProductById(long id);

}
