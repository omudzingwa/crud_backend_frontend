package com.quadrant.zest_backend.users;

import com.quadrant.zest_backend.products.Products;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin("*")
@RequestMapping("/users")
public class UsersController {

    private final UsersService usersService;

    public UsersController(UsersService usersService) {
        this.usersService = usersService;
    }

    @PostMapping("/save")
    public ResponseEntity<?> saveUser(@RequestBody Users users){
        usersService.saveProduct(users.getUsername(), users.getPassword());
        return new ResponseEntity<>("User saved successfully", HttpStatus.OK);
    }

    @GetMapping("/listall")
    public ResponseEntity<?> listAllProducts(){
        return new ResponseEntity<>(usersService.listAllUsers(),HttpStatus.OK);
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<?> updateUserPassword(@RequestBody Users users, @PathVariable("id") long id){
        usersService.updateUser(users.getUsername(),users.getPassword(),id);
        return new ResponseEntity<>("User password updated", HttpStatus.OK);
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<?> deleteUser(@PathVariable("id") long id){
        usersService.deleteUserById(id);
        return new ResponseEntity<>("User deleted", HttpStatus.OK);
    }

    @GetMapping("/findbyid/{id}")
    public ResponseEntity<?> findUserById(@PathVariable("id") long id){
        String userToFind = String.valueOf(usersService.findUserById(id));
        return new ResponseEntity<>(userToFind,HttpStatus.OK);
    }

}
