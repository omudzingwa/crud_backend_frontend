package com.quadrant.zest_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZestBackendApplicationTests {

    @Test
    void contextLoads() {
    }

}
