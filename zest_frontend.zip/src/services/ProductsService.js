import axios from "axios";

const BASE_URL = "http://localhost:9999/products";

class ProductsService {
  saveProduct(product) {
    return axios.post(BASE_URL + "/save", product);
  }

  listProducts() {
    return axios.get(BASE_URL + "/listall");
  }

  updateProductPrice(id) {
    return axios.put(BASE_URL + "/update/" + id);
  }

  deleteProduct(id) {
    return axios.delete(BASE_URL + "/delete/" + id);
  }
}

export default new ProductsService();
