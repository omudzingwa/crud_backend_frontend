import axios from "axios";

const BASE_URL = "http://localhost:9999/users";

class UsersService {
  saveUser(user) {
    return axios.post(BASE_URL + "/save", user);
  }

  listAllUsers() {
    return axios.get(BASE_URL + "/listall");
  }

  updateUser(id) {
    return axios.put(BASE_URL + "/update/" + id);
  }

  deleteUser(id) {
    return axios.delete(BASE_URL + "/delete/" + id);
  }

  findUserById(id) {
    return axios.get(BASE_URL + "/findbyid/" + id);
  }
}

export default new UsersService();
