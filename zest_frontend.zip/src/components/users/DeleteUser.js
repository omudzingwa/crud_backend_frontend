import React from "react";

const DeleteUser = () => {
  return (
    <div>
      <h1>Delete Users Page</h1>
    </div>
  );
};

export default DeleteUser;
