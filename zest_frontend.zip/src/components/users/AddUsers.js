import React, { useState } from "react";
import "bootstrap/dist/css/bootstrap.css";
import UsersService from "../../services/UsersService";
import { useNavigate } from "react-router-dom";

const AddUsers = () => {
  //Step 1
  //Create the User object and then initialize its state using useState Hook
  const [user, setUser] = useState({
    username: "",
    password: "",
  });

  const navigate = useNavigate();

  //Step 2
  //Handle change
  const handleChange = (event) => {
    setUser({ ...user, [event.target.name]: event.target.value });
  };

  //Step 3
  //Save User data into database
  const saveUserData = (event) => {
    event.preventDefault();
    UsersService.saveUser(user)
      .then((response) => {
        console.log(response);
        //Reset the form fields
        setUser({
          username: "",
          password: "",
        });
      })
      .catch((error) => {
        console.log(error);
      });
  };

  return (
    <div className="container">
      <div className="row">
        <div className="col-md-6 border offset-3 mt-4 rounded border">
          <form onSubmit={saveUserData}>
            <div className="text text-center">
              <h1 className="text text-center">Save User Information</h1>
            </div>
            <div className="text text-start">
              <div>
                <label className="form-label" htmlFor="username">
                  Username
                </label>
                <input
                  type="text"
                  className="form-control"
                  id="username"
                  name="username"
                  placeholder="Enter username"
                  required
                  value={user.username}
                  onChange={(event) => handleChange(event)}
                />
              </div>
              <div>
                <label className="form-label" htmlFor="password">
                  Password
                </label>
                <input
                  type="text"
                  className="form-control"
                  id="password"
                  name="password"
                  placeholder="Enter password"
                  required
                  value={user.password}
                  onChange={(event) => handleChange(event)}
                />
              </div>
            </div>

            <button
              type="submit"
              className="btn  btn-primary mt-3 mb-3 col-md-3"
            >
              Submit
            </button>
            <button
              className="btn btn-warning mx-2 col-md-3"
              onClick={() => navigate("/")}
            >
              Cancel
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default AddUsers;
