import React, { useEffect, useState } from "react";
import UsersService from "../../services/UsersService";
import { useNavigate, Link, useParams } from "react-router-dom";

const ListUsers = () => {
  //Step 1
  //Create the User object and then initiliaze it with useState Hook
  const [users, setUsers] = useState([]);

  //Load the users on page load using useEffect Hook
  useEffect(() => {
    loadUsers();
  }, []);

  const loadUsers = () => {
    UsersService.listAllUsers().then((response) => {
      setUsers(response.data);
    });
  };

  const { id } = useParams();

  const deleteUser = (id) => {
    UsersService.deleteUser(id)
      .then(() => {
        console.log("User deleted");
      })
      .catch((error) => {
        console.log(error);
      });
  };

  const navigate = useNavigate();

  return (
    <div className="container">
      <div className="row">
        <div className="col-md">
          <div className=" text text-center mt-3">
            <h1>List of all Users</h1>
          </div>
          <table className="table table-dark table-striped">
            <thead>
              <tr>
                <th scope="col">ID</th>
                <th scope="col">Username</th>
                <th scope="col">Password</th>
                <th colSpan={3}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {users.map((user, counter) => (
                <tr key={user.id}>
                  <td>{counter + 1}</td>
                  <td>{user.username}</td>
                  <td>{user.password}</td>
                  <td>
                    <button className="btn btn-primary mx-2 col-md-2">
                      View
                    </button>
                    <Link
                      className="btn btn-warning mx-2 col-md-2"
                      to={`/edit-user/${user.id}`}
                    >
                      Update
                    </Link>
                    <button
                      className="btn btn-danger mx-2 col-md-2"
                      onClick={() => deleteUser(user.id)}
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default ListUsers;
