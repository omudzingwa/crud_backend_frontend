import React, { useState } from "react";
import ProductsService from "../../services/ProductsService";

const AddProducts = () => {
  //Step 1
  //Create the product object and then initialize its state using useState hook
  const [product, setProduct] = useState({
    //initialise the objects
    name: "",
    price: "",
  });

  //Step 2
  //Capture onChange events
  const handleChange = (event) => {
    setProduct({ ...product, [event.target.name]: event.target.value });
  };

  //Step 3
  //Save data into database
  const saveProduct = (event) => {
    //prevent page reload
    event.preventDefault();
    //Call user service to save the user
    ProductsService.saveProduct(product)
      .then((response) => {
        console.log(response);
        setProduct({
          name: "",
          price: "",
        });
      })
      .catch((error) => {
        console.log(error);
      });
  };

  //Step 4
  //Create the Product form and call handleChange() and saveProduct methods
  return (
    <div className="container-fluid">
      <div className="row">
        <div className="col-md-6 offset-md-3 border rounded mt-3 shadow">
          <form onSubmit={saveProduct}>
            <div className="text text-center">
              <h1>Add Products</h1>
            </div>
            <div className=" text text-start">
              <div>
                <label className="form-label" htmlFor="name">
                  Name
                </label>
                <input
                  type="text"
                  className="form-control"
                  name="name"
                  id="name"
                  required
                  placeholder="Enter product name"
                  value={product.name}
                  onChange={(event) => handleChange(event)}
                />
              </div>
              <div>
                <label className="form-label" htmlFor="price">
                  Price
                </label>
                <input
                  type="text"
                  className="form-control"
                  name="price"
                  id="price"
                  required
                  placeholder="Enter product price"
                  value={product.price}
                  onChange={(event) => handleChange(event)}
                />
              </div>
              <div className="text text-center">
                <button
                  type="submit"
                  className="btn btn-primary mt-3 mb-3 col-md-3"
                >
                  Save
                </button>
                <button className="btn btn-outline-warning mt-3 mb-3 col-md-3 mx-3">
                  Cancel
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default AddProducts;
