import React from "react";

const EditProducts = () => {
  return <div>EditProducts</div>;
};

export default EditProducts;
