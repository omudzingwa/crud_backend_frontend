import "./App.css";
import Home from "./components/common/Home";
import NavBar from "./components/common/NavBar";
import AddProducts from "./components/products/AddProducts";
import EditProduct from "./components/products/EditProduct";
import ListProducts from "./components/products/ListProducts";
import DeleteProduct from "./components/products/DeleteProduct";
import AddUsers from "./components/users/AddUsers";
import ListUsers from "./components/users/ListUsers";
import DeleteUser from "./components/users/DeleteUser";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import EditUser from "./components/users/EditUser";

function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <NavBar />
        <div className="container">
          <Routes>
            <Route exact path="/" element={<Home />} />
            <Route exact path="/add-products" element={<AddProducts />} />
            <Route exact path="/view-products" element={<ListProducts />} />
            <Route exact path="/edit-product/:id" element={<EditProduct />} />
            <Route
              exact
              path="/delete-product/:id"
              element={<DeleteProduct />}
            />
            <Route exact path="/add-users" element={<AddUsers />} />
            <Route exact path="/view-users" element={<ListUsers />} />
            <Route exact path="/edit-user/:id" element={<EditUser />} />
            <Route exact path="/delete-user/:id" element={<DeleteUser />} />
          </Routes>
        </div>
      </BrowserRouter>
    </div>
  );
}

export default App;
